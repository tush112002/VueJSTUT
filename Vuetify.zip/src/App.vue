<template>
  <div id="app">
    <Header @search="handleSearch" />
    <!-- <Profile/>
    <Home/> -->
    <!-- <View/> -->
    <router-view  :search="searchQuery"/>
    <Footer/>
  </div>
</template>

<script setup>
import { defineEmits } from 'vue';
import Header from './components/Home/Header.vue';
import Footer from './components/Home/Footer.vue';
import Profile from './components/Profile/Profile.vue'
import Home from './components/Home/Home.vue';
import View from './components/View/View.vue';

const emit = defineEmits(['search']);

import { ref } from 'vue';

const searchQuery = ref('');

const handleSearch = (query) => {
  searchQuery.value = query;
  console.log("Search from App ", searchQuery.value);
};
</script>


<style>
</style>
