<template>
  <div>
    <div v-for="video in filteredVideos" :key="video.id">
      <router-link :to="'/view/' + video.id">
        <div class="card">
          <img :src="video.imgSrc" :alt="'Card Image ' + video.id" class="card-image">
          <div class="card-details">
            <h3 class="card-title">{{ video.title }}</h3>
            <p class="card-views">Views: {{ video.views }}</p>
            <p class="card-desc">{{ video.desc }}</p>
            <p class="card-firstname">{{ video.creator.firstname }}</p>
            <p class="card-lastname">{{ video.creator.lastname }}</p>
          </div>
        </div>
      </router-link>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import Data from '../../assets/config/data.json';

const props=defineProps({
  searchQuery:{
    type:String,
    default:''
  }
})

const videolist = ref(Data);
console.log("Search from card : ", props.searchQuery.value);


const filteredVideos = computed(() => {
  return videolist.value.filter(video =>
    video.title.toLowerCase().includes(props.searchQuery.toLowerCase())
  );
});

</script>

<style scoped>
.card {
  display: flex;
  margin: 20px;
  border-radius: 8px;
  overflow: hidden;
  transition: box-shadow 0.3s ease-in-out;
}

.card:hover {
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
}

.card-image {
  width: 300px;
  height: auto;
  border-top-left-radius: 8px;
  border-bottom-left-radius: 8px;
  transition: transform 0.3s ease-in-out;
}

.card:hover .card-image {
  transform: scale(1.05);
}

.card-details {
  flex: 1;
  padding: 20px;
}

.card-title {
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 10px;
}

.card-views {
  font-size: 14px;
  color: black;
  margin-bottom: 5px;
}

.card-info {
  font-size: 14px;
}

.card:last-child {
  margin-bottom: 70px;
}
</style>

