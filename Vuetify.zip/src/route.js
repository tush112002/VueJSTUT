import { createRouter, createWebHistory } from 'vue-router'
import View from './components/View/View.vue'
import Home from './components/Home/Home.vue'
import Profile from './components/Profile/Profile.vue'

const routes = [
    {
        name: 'Home',
        component: Home,
        path: '/',
        props: true,
    },
    {
        name: 'View',
        component: View,
        path: '/view/:id',
        props: true
    },
    {
        name: 'Profile',
        component: Profile,
        path: '/profile',
        props: true
    }

]

const router = createRouter({
    history: createWebHistory(),
    routes
})


export default router

